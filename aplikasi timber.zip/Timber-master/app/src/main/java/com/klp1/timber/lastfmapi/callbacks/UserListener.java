package com.klp1.timber.lastfmapi.callbacks;



/**
 * Created by christoph on 17.07.16.
 */
public interface UserListener {
    void userSuccess();

    void userInfoFailed();

}
