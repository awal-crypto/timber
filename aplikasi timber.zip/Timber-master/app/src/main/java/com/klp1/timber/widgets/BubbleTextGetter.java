package com.klp1.timber.widgets;

public interface BubbleTextGetter {
    String getTextToShowInBubble(int pos);
}