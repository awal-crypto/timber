package com.klp1.timber.widgets.desktop;

import com.klp1.timber.R;

/**
 * Created by nv95 on 11.11.16.
 */

public class WhiteWidget extends StandardWidget {

    @Override
    int getLayoutRes() {
        return R.layout.widget_white;
    }
}
